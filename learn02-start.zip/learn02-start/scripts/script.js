function myFunction2() {
    document.getElementById("sample").innerHTML =
        "Changed from a function in an external script.";
}